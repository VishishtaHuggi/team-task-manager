function App() {
  return (
    <div style={{padding:'40px'}}>
      <h1>Team Task Manager</h1>
      <p>Project setup completed.</p>
    </div>
  );
}

export default App;
